
$ echo $x
