
<!--This is a comment in HTML.
Save this file as index.html-->
<!-- http://tinyurl.com/h3bjuov -->


<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Website</title>
</head>
<body>
     Hello, World!
     <a href="https://www.google.com/>
     click here</a>
</body>
</html>
