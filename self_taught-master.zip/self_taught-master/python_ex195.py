
fict = ["Tolstoy",
        "Camus",
        "Orwell",
        "Huxley",
        "Austin"]
fict[0:3]
