
pip freeze
