
fruits = {"Apple":
          "Red",
          "Banana":
          "Yellow"}
fruits
