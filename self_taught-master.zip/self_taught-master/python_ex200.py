
# http://tinyurl.com/ho5nyj2


name = "Ted"
for character in name:
    print(character)
