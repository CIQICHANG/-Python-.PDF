
card = Card(3, 2)
print(card)
