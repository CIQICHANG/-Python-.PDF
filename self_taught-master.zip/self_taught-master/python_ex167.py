
"cat" + "in" + "hat"
