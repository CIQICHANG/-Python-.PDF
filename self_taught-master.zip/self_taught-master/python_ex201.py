
# http://tinyurl.com/gmptmlk


shows = ["GOT",
         "Narcos",
         "Vice"]
for show in shows:
    print(show)
