
$ rmdir tstp
