
# code in module1
if __name__ == "__main__":
    print("Hello!")
