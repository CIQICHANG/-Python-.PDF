
"Hello".replace("o", "@")
