
if x > 100:
    print("x is > 100")
