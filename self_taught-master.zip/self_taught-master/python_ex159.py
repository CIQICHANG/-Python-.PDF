# Thanks so much for reading my book. Feel free to contact me at cory[at]theselftaughtprogrammer.io.


bday = {"Hemingway":
        "7.21.1899",
        "Fitzgerald":
        "9.24.1896"}


my_list = [bday]
print(my_list)
my_tuple = (bday,)
print(my_tuple)
