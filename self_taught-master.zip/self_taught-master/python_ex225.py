
# code in module1
print("Hello!")
