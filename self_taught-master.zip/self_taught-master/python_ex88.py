# Continue from
# last example

result = f(2)
print(result)
