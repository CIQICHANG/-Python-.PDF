
try:
    10 / 0
    c = "I will never get defined."
except ZeroDivisionError:
    print(c)
