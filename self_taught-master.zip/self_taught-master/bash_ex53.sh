
        $ git log
