
$ touch .self_taught
