# Continue from
# last example

f(2)
