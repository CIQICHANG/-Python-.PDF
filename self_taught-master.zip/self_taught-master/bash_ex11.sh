
$ cd tstp
