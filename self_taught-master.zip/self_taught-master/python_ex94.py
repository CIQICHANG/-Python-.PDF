
len("Python")
