
$ git pull origin master
