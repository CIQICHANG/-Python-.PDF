
# http://tinyurl.com/jtfntw8


def f():
    return 1 + 1


result = f()
print(result)
