
$ ls
>> hangman
