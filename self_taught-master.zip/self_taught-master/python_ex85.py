# Do not run.

def [function_name]([parameters]):
    [function_definition]
