
print("line1\nline2\nline3")
