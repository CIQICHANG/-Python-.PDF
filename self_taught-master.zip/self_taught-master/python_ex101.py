
# http://tinyurl.com/j4dryde


def even_odd(x):
    if x % 2 == 0:
        print("even")
    else:
        print("odd")


even_odd(2)
even_odd(3)
