
# http://tinyurl.com/jml4r9l


def f():
    z = 1 + 1


result = f()
print(result)
