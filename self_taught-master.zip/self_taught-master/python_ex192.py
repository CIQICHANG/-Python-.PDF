
"She said 'Surely.'"
