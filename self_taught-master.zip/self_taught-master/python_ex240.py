
x = 2
y = 4
z = 8
xyz = x + y + z
xyz
