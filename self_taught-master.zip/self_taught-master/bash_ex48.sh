
$ git reset hangman.py.
