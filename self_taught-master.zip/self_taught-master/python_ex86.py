
# https://goo.gl/O7wFg7


def f(x):
    return x * 2
