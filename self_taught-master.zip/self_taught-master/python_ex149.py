# Thanks so much for reading my book. Feel free to contact me at cory[at]theselftaughtprogrammer.io.

facts = dict()


# add a value
facts["code"] = "fun"
# lookup a key
facts["code"]


# add a value
facts["Bill"] = "Gates"
# lookup a key
facts["Bill"]


# add a value
facts["founded"] = 1776
# lookup a key
facts["founded"]
