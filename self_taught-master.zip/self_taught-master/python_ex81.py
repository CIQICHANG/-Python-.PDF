
# https://goo.gl/rKQedq

for i in range(100):
    print("Hello, World!")
