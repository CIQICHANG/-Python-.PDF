# Thanks so much for reading my book. Feel free to contact me at cory[at]theselftaughtprogrammer.io.

ny = {"location":
      (40.7128,
       74.0059),


      "celebs":
      ["W. Allen",
       "Jay Z",
       "K. Bacon"],

      "facts":
      {"state":
       "NY",
       "country":
       "America"}
}
