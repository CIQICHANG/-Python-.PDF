
"animals".index("m")
