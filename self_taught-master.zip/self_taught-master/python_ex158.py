# Thank you so much for purchasing my book! Feel free to contact me at cory[at]theselftaughtprogrammer.io.
# If you are enjoying it, please consider leaving a review on Amazon :). Keep up the hard work!

eights = ["Edgar Allan Poe",
          "Charles Dickens"]


nines = ["Hemingway",
         "Fitzgerald",
         "Orwell",
         "Sinclair"]


authors = (eights, nines)
print(authors)
