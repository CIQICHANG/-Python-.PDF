# Thanks so much for reading my book. Feel free to contact me at cory[at]theselftaughtprogrammer.io.

import statistics

# mean
nums = [1, 5, 33, 12, 46, 33, 2]
statistics.mean(nums)


# median
statistics.median(nums)


# mode
statistics.mode(nums)
