
# this is an extension
# of the previous example


rap = lists[0]
rap.append("Kendrick Lamar")
print(rap)
print(lists)
