
$ grep beautiful zen.txt
