# Thanks so much for reading my book. Feel free to contact me at cory[at]theselftaughtprogrammer.io.


equ = "All animals are equal."
equ = equ.replace("a", "@")
print(equ)
