
$ cd ..
