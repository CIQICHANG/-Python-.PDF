
# http://tinyurl.com/za4sf79


with open("st.txt", "w") as f:
    f.write("hi from Python!")
