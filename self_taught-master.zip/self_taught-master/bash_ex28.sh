
$  grep idea.$ zen.txt
