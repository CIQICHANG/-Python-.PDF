
$ echo __hi__bye__I__! | grep -o __.*__
