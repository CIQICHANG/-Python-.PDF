
random = []
random.append(True)
random.append(100)
random.append(1.1)
random.append("Hello")
random
