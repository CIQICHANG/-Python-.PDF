
dys = ("1984",
       "Brave New World",
       "Fahrenheit 451")

"1984" in dys
