
$ echo 123?34 hello? | grep [[:digit:]]
