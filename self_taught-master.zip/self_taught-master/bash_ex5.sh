
$ pwd
