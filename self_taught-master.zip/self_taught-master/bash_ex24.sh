
$ grep -i beautiful zen.txt
