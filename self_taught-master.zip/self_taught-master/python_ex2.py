
for i in range(100):
    print("Hello, World!")
