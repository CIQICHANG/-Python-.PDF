# Thank you so much for purchasing my book! Feel free to contact me at cory[at]theselftaughtprogrammer.io.
# If you are enjoying it, please consider leaving a review on Amazon :). Keep up the hard work!


class Orange:
    def __init__(self, w, c):
        self.weight = w
        self.color = c
        print("Created!")
