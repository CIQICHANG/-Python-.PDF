
$ grep ^If zen.txt
