
# even
12 % 2
