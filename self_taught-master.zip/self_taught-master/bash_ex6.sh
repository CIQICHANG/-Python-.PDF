
$ cd /
