# Do not run.
f(x) = x * 2
