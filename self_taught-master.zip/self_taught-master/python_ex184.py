
"animals".index("z")
