
If (expression) Then
           (code_area1)
Else
           (code_area2)
