
"cat " + " in" + " the" + " hat"
