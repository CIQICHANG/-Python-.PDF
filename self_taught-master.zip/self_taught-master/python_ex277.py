
deck = Deck()
for card in deck.cards:
   print(card)
