# Thanks so much for reading my book. Feel free to contact me at cory[at]theselftaughtprogrammer.io.

ivan = """In place of death there \
was light."""

ivan[:]
