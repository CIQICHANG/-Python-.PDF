
stack = Stack()


for i in range(0, 6):
    stack.push(i)


print(stack.peek())
print(stack.size())
