
'She said \"Surely.\"'
