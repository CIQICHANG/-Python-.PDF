# Thanks so much for reading my book. Feel free to contact me at cory[at]theselftaughtprogrammer.io.

home = "Canada"
if home == "America":
    print("Hello, America!")
else:
    print("Hello, World!")
