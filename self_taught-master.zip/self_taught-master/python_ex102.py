# Thank you so much for purchasing my book! Feel free to contact me at cory[at]theselftaughtprogrammer.io.
# If you are enjoying it, please consider leaving a review on Amazon :).
# https://www.amazon.com/dp/B01M01YDQA#customerReviews. Keep up the hard work!

n = input("type a number")
n = int(n)


if n % 2 == 0:
    print("n is even.")
else:
    print("n is odd.")


n = input("type a number")
n = int(n)
if n % 2 == 0:
    print("n is even.")
else:
    print("n is odd.")


n = input("type a number")
n = int(n)
if n % 2 == 0:
    print("n is even.")
else:
    print("n is odd.")
