
"four score and...".capitalize()
