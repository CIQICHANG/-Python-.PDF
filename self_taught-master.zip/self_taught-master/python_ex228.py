
# code in module2
import hello
