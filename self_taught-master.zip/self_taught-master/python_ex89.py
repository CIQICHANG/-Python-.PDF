
# http://tinyurl.com/grosm7v


def f(x):
    return x + 1


z = f(4)


if z == 5:
    print("z is 5")
else:
    print("z is not 5")
