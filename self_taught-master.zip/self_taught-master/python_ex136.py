
len(colors)
