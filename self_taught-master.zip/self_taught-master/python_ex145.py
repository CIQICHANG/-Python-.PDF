
dys = ("1984",
            "Brave New World",
            "Fahrenheit 451")

"Handmaid's Tale" not in dys
