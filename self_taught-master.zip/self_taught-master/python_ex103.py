# Thanks so much for reading my book. Feel free to contact me at cory[at]theselftaughtprogrammer.io with any questions.



def even_odd():
    n = input("type a number")
    n = int(n)
    if n % 2 == 0:
        print("n is even.")
    else:
        print("n is odd.")


even_odd()
even_odd()
even_odd()
