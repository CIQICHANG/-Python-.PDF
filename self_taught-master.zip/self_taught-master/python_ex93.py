
len("Monty")
