# Thank you so much for purchasing my book! Feel free to contact me at cory[at]theselftaughtprogrammer.io.
# If you are enjoying it, please consider leaving a review on Amazon :). Keep up the hard work!

books = {"Dracula": "Stoker",
         "1984": "Orwell",
         "The Trial": "Kafka"}


del books["The Trial"]

books
