
print("Michael")






print("Jordan")
