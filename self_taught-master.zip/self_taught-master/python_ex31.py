
x = 10
x = x - 1
x
