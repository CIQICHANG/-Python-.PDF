
# The output might not be 52
# when you run it—it’s random!


import random


random.randint(0,100)
