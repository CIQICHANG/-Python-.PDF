# Thanks so much for reading my book. Feel free to contact me at cory[at]theselftaughtprogrammer.io.

dys = ("1984",
            "Brave New World",
            "Fahrenheit 451")

dys[1] = "Handmaid's Tale"
