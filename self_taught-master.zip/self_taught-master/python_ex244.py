# Thanks so much for reading my book. Feel free to contact me at cory[at]theselftaughtprogrammer.io.

class Orange:
    def __init__(self):
        print("Created!")
