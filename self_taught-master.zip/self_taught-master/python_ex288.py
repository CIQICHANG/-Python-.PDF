
# http://tinyurl.com/ztysa6b


import urllib.request
from bs4 import BeautifulSoup
