
colors = ["blue","green","yellow"]
colors
colors[2] = "red"
colors
