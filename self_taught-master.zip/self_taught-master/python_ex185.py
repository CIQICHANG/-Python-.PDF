
try:
    "animals".index("z")
except:
    print("Not found.")
