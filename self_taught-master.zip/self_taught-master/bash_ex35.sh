
$ echo I love $ | grep  \$
