
# https://goo.gl/S6Z9rp


x = 10
y = 11


if x == 10:
    if y == 11:
        print(x + y)
