
$ mkdir tstp
