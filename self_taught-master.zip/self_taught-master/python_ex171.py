
"SO IT GOES.".lower()
