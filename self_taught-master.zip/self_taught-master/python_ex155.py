# Thanks so much for reading my book. Feel free to contact me at cory[at]theselftaughtprogrammer.io.

# Continue from
# last example

rap = lists[0]
print(rappers)
