# Thanks so much for reading my book. Feel free to contact me at cory[at]theselftaughtprogrammer.io.

last = "Faulkner"
"William {}".format(last)
