
int("110")
int(20.54)


float("16.4")
float(99)
