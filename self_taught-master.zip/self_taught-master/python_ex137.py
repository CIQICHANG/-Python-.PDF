
# http://tinyurl.com/jmjee5u


colors = ["purple", "orange", "green"]


guess = input("Guess a color:")


if guess in colors:
    print("You guessed correctly!")
else:
    print("Wrong! Try again.")
