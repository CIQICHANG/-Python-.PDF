# Thank you so much for purchasing my book! Feel free to contact me at cory[at]theselftaughtprogrammer.io.
# If you are enjoying it, please consider leaving a review on Amazon :). Keep up the hard work!

ivan = """In place of death there \
was light."""

ivan[0:17]
ivan[17:33]
