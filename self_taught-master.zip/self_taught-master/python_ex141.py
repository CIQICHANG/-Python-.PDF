
# this is a tuple
("self_taught",)


# this is not a tuple
(9) + 1
