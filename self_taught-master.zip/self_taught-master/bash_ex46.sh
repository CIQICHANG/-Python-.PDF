
$ git add hangman.py
