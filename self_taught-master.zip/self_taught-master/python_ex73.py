
# https://goo.gl/jOlzVl


home = "America"
if home == "America":
    print("Hello, America!")
