# Thanks so much for reading my book. Feel free to contact me at cory[at]theselftaughtprogrammer.io.


# Continue from
# last example

mick = Person("Mick Jagger")
stan = Dog("Stanley",
           "Bulldog",
           mick)
print(stan.owner.name)
