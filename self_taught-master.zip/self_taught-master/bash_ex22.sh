
 $ grep Beautiful zen.txt
