
$ git status
