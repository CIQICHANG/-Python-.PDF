# Thanks so much for reading my book. Feel free to contact me at cory[at]theselftaughtprogrammer.io.

if not win:
    print("\n"
          .join(stages[0: \
          wrong]))
    print("You lose! It was {}."
          .format(word))
