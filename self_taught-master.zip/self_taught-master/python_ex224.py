
# http://tinyurl.com/zdv7xyl


import hello


hello.print_hello()
