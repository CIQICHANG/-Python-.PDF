
rndm = ("M. Jackson", 1958, True)
rndm
