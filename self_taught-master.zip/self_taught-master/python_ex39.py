# This code has an error.

10 / 0
