# Thank you so much for purchasing my book! Feel free to contact me at cory[at]theselftaughtprogrammer.io.
# If you are enjoying it, please consider leaving a review on Amazon :). https://www.amazon.com/dp/B01M01YDQA#customerReviews. Keep up the hard work!

home = "America"
if home == "America":
    print("Hello, America!")
else:
    print("Hello, World!")
