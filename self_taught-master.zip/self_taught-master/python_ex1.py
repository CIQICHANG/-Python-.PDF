# Thank you so much for purchasing my book! Feel free to contact me at cory[at]theselftaughtprogrammer.io.

print("Hello, World!")
