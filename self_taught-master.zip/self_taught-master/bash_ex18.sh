
$ ls | less
