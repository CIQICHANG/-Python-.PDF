
my_dict = dict()
my_dict
