
fruit = ["Apple", "Orange", "Pear"]
