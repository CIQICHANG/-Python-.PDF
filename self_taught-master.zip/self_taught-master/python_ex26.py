# Do not run.


int a;
a = 144;
