
print(100)
