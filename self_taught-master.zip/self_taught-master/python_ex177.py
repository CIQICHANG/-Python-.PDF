# Thanks so much for reading my book. Feel free to contact me at cory[at]theselftaughtprogrammer.io.

"""Hello.Yes!""".split(".")
