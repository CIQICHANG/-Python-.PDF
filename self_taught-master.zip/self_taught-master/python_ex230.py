
# http://tinyurl.com/zymnkgn


st = open("st.txt", "w")
st.write("hi from Python!")
st.close()
