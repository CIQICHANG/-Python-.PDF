# Thanks so much for reading my book. Feel free to contact me at cory[at]theselftaughtprogrammer.io.

ff = "F. Fitzgerald"
ff = "F. Scott Fitzgerald"
ff
