
colors = ["blue","green","yellow"]
"green" in colors
