
$ history
