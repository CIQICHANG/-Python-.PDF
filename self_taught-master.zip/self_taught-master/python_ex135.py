
colors = ["blue","green","yellow"]
"black" not in colors
