
# http://tinyurl.com/h27ya5h


# make sure you’ve
# created the file from
# the previous example


with open("st.txt", "r") as f:
    print(f.read())
