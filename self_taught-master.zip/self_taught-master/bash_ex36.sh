
$ pip
