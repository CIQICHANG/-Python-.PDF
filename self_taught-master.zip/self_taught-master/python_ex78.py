# Thanks so much for reading my book. Feel free to contact me at cory[at]theselftaughtprogrammer.io.

x = 100
if x == 10:
    print("10!")
elif x == 20:
    print("20!")
else:
    print("I don’t know!")


if x == 100:
    print("x is 100!")


if x % 2 == 0:
    print("x is even!")
else:
    print("x is odd!")
