
'She said "Surely."'
