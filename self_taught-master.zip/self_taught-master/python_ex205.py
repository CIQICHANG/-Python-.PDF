
tv = ["GOT", "Narcos",
      "Vice"]
for i, show in enumerate(tv):
    new = tv[i]
    new = new.upper()
    tv[i] = new


print(tv)
