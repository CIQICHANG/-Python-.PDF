# Thanks so much for reading my book. Feel free to contact me at cory[at]theselftaughtprogrammer.io.


author = "William Faulkner"
year_born = "1897"

"""{} was born in {}."""\
   .format(author,
           year_born)
