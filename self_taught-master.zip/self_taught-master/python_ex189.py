
"She said "Surely.""
