
# http://tinyurl.com/jg586u7


locations = []


la = (34.0522, 188.2437)
chicago = (41.8781, 87.6298)


locations.append(la)
locations.append(chicago)


print(locations)
