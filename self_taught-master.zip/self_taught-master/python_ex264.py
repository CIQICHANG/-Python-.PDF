
# http://tinyurl.com/hnb5348


class Square:
    pass


print(Square)
