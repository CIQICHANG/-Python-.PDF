
# http://tinyurl.com/hdg7jpq


while True:
    print("Hello, World!")


