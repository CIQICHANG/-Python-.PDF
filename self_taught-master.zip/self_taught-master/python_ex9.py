
print("Python")
