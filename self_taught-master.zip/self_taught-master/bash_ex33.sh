
$ echo __hello__there | grep -o __.*__
