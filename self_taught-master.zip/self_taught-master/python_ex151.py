
bill = dict({"Bill Gates":
                 "charitable"})


"Bill Doors" not in bill
