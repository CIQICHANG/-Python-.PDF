
# http://tinyurl.com/jos8sza


x = 10
if x is None:
    print("x is None :( ")
else:
    print("x is not None")


x = None
if x is None:
    print("x is None")
else:
    print("x is not None :( ")
