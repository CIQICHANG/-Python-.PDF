

new__york = {"location": (40.7128, 74.0059),
             "celebrities": ["Sean Parker", "Rosie O'Donnel", "Neil Patrick Harris"],
             "facts":  {"state": "NY", "country": "America"}
}
