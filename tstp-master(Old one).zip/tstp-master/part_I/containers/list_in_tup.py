

eighteen_hundreds = ["Edgar Allen Poe", "Charles Dickens"]
nineteen_hundreds = ["Hemingway", "Fitzgerald", "Orwell"]

authors = (eighteen_hundreds, nineteen_hundreds)
print(authors)
