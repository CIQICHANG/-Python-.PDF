
author_bday = {"Hemingway": "7.21.1899",
               "Fitzgerald": "9.24.1896"}

my_list = [author_bday]
print(my_list)
my_tuple = (author_bday,)
print(my_tuple)
