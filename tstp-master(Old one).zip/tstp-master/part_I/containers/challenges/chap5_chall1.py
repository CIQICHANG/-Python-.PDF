fav_musicans = ["Jay Z", "Adventure Club", "John Lennon"]
