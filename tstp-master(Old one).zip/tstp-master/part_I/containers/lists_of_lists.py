

list_of_lists = []
rappers = ["Kanye West", "Jay Z", "Eminem", "Nas"]
rockers = ["Bob Dylan", "The Beatles", "Led Zeppelin"]
djs = ["Zeds Dead", "Tiesto"]

list_of_lists.append(rappers)
list_of_lists.append(rockers)
list_of_lists.append(djs)

print(list_of_lists)

rappers = list_of_lists[0]
print(rappers)

rappers = list_of_lists[0]
rappers.append("Kendrick Lamar")
print(rappers)
print(list_of_lists)

rappers = list_of_lists[0]
print(rappers)

rappers = list_of_lists[0]
rappers.append("Kendrick Lamar")
