
def f(x):
    return x * 2

result = f(2)
print(result)
