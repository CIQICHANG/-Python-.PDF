

def f():
    pass
