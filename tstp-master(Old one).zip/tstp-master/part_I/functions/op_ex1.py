
def f(x=2):
    return x**x


print(f())
print(f(4))
