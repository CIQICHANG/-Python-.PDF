
def f():
    print("This is part of the function f.")
print("this is not part of function f")
f()
