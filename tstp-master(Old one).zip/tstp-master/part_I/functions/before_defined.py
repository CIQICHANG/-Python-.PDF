if x > 100:
    print("x is greater than 100")

x = 110