

x = 1
y = 2
z = 3


def f():
    print(x)
    print(y)
    print(z)

f()

