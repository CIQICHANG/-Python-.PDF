

def f(x, y, z):
    return x + y + z

result = f(1, 2, 3)
print(result)
