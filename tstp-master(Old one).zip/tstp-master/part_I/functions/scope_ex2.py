

x = 100


def f():
    x = x + 1
    print()

f()
