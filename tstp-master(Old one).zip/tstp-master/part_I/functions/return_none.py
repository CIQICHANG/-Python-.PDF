
def f():
    z = 1 + 1

result = f()
print(result)
