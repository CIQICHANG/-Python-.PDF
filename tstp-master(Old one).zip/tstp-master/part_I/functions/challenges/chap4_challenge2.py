def print_string(string):
    print(string)

print_string("Testing: 1, 2, 3.")
