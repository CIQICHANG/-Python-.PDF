def add_mult(a,b,c,x=100,z=1000):
    return a + b + c * x * z

result = add_mult(10, 15, 25)
print(result)
