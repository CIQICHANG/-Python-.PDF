print("Above")
print("and")
print("beyond")
