x = 2

if x <= 10:
    print("x is less than or equal to 10.")
elif x <= 25:
    print("x is greater than 10, but less than or equal to 25.")
else:
    print("x is greater than 25.")
