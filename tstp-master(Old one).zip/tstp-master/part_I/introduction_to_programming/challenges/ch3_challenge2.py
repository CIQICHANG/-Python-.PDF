x = 11
if x < 10:
    print("x is less than 10.")
else:
    print("x is greater than or equal to 10")
