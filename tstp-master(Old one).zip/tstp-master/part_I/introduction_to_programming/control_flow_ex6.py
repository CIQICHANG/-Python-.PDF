

country = "Thailand"
if country == "Japan":
    print("Hello, Japan!")
elif country == "Thailand":
    print("Hello, Thailand!")
elif country == "India":
    print("Hello, India!")
elif country == "China":
    print("Hello, China!")
else:
    print("Hello, World!")
