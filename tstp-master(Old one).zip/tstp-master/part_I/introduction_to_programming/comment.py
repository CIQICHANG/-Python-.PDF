
 
# This is a comment
print("The comment does not affect this code")

2 - 2

"hello"
