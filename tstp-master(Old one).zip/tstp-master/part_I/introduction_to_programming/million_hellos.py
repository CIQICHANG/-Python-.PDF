
for i in range(1000001):
    print("Hello World")
