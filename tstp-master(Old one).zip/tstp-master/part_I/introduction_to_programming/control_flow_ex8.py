

x = 100
if x == 10:
    print("10!")
elif x == 20:
    print("20!")
else:
    print("I don’t know what x is!")


if x == 100:
    print("x is 100!")

if x % 2 == 0:
    print("x is even!")
else:
    print("x is odd!")
