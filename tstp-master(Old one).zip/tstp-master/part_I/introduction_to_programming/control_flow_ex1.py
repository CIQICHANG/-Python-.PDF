
country = "America"
if country == "America":
    print("Hello, America!")
else:
    print("Hello, World!")
