

country = "Mars"
if country == "America":
    print("Hello, America!")
elif country == "Canada":
    print("Hello, Canada!")
elif country == "Thailand":
    print("Hello, Thailand!")
elif country == "Mexico":
    print("Hello, Mexico!")
else:
    print("Hello, World!")
