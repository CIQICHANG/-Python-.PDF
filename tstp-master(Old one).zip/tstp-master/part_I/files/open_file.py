

my_file = open("self_taught.txt", "w")
my_file.write("Hello from Python!")
my_file.close()
