

with open("self_taught.txt", "w") as my_file:
    my_file.write("Hello from Python!")
