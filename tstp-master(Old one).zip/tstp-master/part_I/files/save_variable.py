
my_list = list()

with open("self_taught.txt", "r") as my_file:
        my_list.append(my_file.read())


print(my_list)
