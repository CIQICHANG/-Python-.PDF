
# make sure you’ve created the file from the previous example

with open("self_taught.txt", "r") as my_file:
    print(my_file.read())
