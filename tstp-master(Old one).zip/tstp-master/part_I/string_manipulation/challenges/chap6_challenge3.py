x = "aldous huxley was born in 1894. he was born in the United Kingdom.".title()
print(x)
