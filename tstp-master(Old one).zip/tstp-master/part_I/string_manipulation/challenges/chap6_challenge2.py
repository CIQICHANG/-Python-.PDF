answer1 = input("What did you write yesterday?")
answer2 = input("Where did you go yesterday?")

new_string = "Yesterday I wrote a {}. I sent it to {}.".format(answer1, answer2)

print(new_string)
