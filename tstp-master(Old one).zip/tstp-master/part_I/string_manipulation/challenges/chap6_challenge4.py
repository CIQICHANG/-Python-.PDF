lst = "Where now? Who now? When now?".split("?")
print(lst)
