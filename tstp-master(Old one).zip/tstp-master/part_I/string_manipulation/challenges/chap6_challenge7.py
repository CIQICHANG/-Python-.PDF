first_index = "Hemingway".index("H")
print(first_index)
