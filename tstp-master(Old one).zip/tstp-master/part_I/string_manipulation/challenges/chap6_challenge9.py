concat = "three" + "three" + "three"
mult = "three" * 3

print(concat)
print(mult)
