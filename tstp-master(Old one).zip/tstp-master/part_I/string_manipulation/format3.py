

noun1 = input("Enter a noun")
verb = input("Enter a verb")
adj = input("Enter an adjective")
noun2 = input("Enter a noun")

answer = "The {} {} the {} {} ".format(noun1, verb, adj, noun2)
print(answer)
