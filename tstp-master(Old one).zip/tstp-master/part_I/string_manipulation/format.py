

name = "Walter Isaacson"
year_born= "1952"
book1 = "Steve Jobs"
book2 = "Benjamin Franklin"
"""{} was born in {}. He's written books about {} and {}.""".format(name, year_born, book1, book2)
print(book2)
