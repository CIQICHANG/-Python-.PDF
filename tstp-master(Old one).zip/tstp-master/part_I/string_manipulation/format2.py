

author = "walter Isaacson"


favorite_author = "My favorite author is {}. He wrote {}."

