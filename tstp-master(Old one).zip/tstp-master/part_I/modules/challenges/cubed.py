def cube_it(x):
    return x ** 3
