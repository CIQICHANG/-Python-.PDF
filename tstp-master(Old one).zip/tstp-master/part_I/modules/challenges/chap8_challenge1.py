import statistics

data = [14, 3, 11, 133, 4]

result = statistics.median_low(data)

print(result)
