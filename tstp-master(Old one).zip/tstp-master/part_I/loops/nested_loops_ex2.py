

list1 = [1, 2, 3, 4]
list2 = [5, 6, 7, 8]
added_up = []
for i in list1:
    for j in list2:
        added_up.append(i + j)

print(added_up)
