

md = {"key1": "value1", "key2": "value2"}
for key in md:
    print(key)
