for i in range(25,51):
    print(i)
