

people = {"George Bluth II": "Arrested Development",
                       "Barney": "How I Met Your Mother",
                       "Dennis": "Always Sunny"
                       }

for character in people:
    print(character)
