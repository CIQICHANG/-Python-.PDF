
intense_shows = ["Game of Thrones", "Narcos", "Vice"]
comedies = ["Arrested Development", "How I Met Your Mother", "Always Sunny"]
all_shows = []

for show in intense_shows:
    show = show.upper()
    all_shows.append(show)

for show in comedies:
    show = show.upper()
    all_shows.append(show)

print(all_shows)
