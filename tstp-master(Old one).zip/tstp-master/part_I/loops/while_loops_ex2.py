

x = 10
while x > 0:
    print("{}".format(x))
    x -= 1
    print("Happy New Year!")
