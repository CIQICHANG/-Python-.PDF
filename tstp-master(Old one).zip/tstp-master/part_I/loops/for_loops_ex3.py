
shows = ["Game of Thrones", "Narcos", "Vice"]
for show in shows:
    print(show)
