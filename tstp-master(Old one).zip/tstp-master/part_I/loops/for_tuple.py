

comedies = ("Arrested Development", "How I Met Your Mother", "Always Sunny")
for show in comedies:
    print(show)
