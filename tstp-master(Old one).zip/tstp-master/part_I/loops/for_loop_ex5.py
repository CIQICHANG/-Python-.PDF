

md = {"key1": "value1", "key2": "value2"}
print(md)
for key, value in md.iteritems():
    print(key)
    print(value)
