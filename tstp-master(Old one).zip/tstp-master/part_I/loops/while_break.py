

i = 1
while i <= 5:
    if i == 3:
        continue
    print(i)
    i += 1

