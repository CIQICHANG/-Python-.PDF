

class Orange:
    def __init__(self, weight, color):
        self.weight = weight
        self.color = color
        print("Orange object created!")

orange1 = Orange(4, "light orange")
orange2 = Orange(8, "dark orange")
orange3 = Orange(14, "yellow")
