class Apple():
    def __init__(self, color, weight, stem_length, circumference):
        self.color = color
        self.weight = weight
        self.stem_length = stem_length
        self.circumference = circumference
