

class Orange:
    def __init__(self):
        print("Orange object created!")
        self.weight = 6
        self.color = 'orange'

orange = Orange()
print(orange.weight)
print(orange.color)
print(orange)
print(type(orange))
