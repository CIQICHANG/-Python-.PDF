

class Orange:
    print("Orange created!")

    def print_orange(self):
        print(self)

orange = Orange()
orange.print_orange()
print(orange)
