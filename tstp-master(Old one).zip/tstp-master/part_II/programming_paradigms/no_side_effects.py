

def increment(a):
    return a + 1
