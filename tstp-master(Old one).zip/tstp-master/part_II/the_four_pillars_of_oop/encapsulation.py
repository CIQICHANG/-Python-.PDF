

class Data:
    def __init__(self):
        self.numbers = [1, 2, 3, 4, 5]

    def change_data(self, index, n):
        self.numbers[index] = n
