x = [1, 2, 3]
y = x


y[2] = 100
print(x)
print(y)
