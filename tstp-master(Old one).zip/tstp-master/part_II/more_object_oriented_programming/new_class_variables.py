class Liger:
    def __init__(self, name):
        self.name = name

connor = Liger("Connor")
print(connor.name)
