

def add_digits(n):
    digits = len(str(n))
    while digits < 1:
        for digit in n:

