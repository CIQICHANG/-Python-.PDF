#!/usr/bin/env bash
pip install requests
