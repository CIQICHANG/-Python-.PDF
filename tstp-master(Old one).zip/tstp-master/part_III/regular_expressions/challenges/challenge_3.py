import re

match = re.findall(".oo", "The ghost that says boo haunts the loo.")
print(match)
