#!/usr/bin/env bash
grep Dutch zen.txt