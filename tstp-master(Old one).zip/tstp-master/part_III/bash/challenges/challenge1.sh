#!/bin/bash
echo Self-taught
