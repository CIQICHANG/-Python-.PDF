#!/bin/bash
# add the next line to your .profile file.
export python_projects=~
cd $python_projects
