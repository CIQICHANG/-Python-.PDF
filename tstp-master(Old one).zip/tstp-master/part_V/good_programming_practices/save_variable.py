

print\
    ("""This is a really really really really really really really really long line of code.""")
