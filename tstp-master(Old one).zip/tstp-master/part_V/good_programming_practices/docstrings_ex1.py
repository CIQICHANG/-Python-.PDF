
def add(x, y):
    """
    Returns x + y.
    :param x: int first integer to be added.
    :param y: int second integer to be added.
    :return: int sum of x and y.
    """
    return x + y
